package com.geektrust.common;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Properties;

public class CommonUtilsForTest {

	public <T> void setPrivateFieldValue(Class cls, String fieldName, T value, Object clsObj) throws Exception {
		Field field = cls.getDeclaredField(fieldName);
		field.setAccessible(true);
		field.set(clsObj, value);
	}

	public Object getPrivateFieldValue(Class cls, String fieldName, Object clsObj) throws Exception {
		Field field = cls.getDeclaredField(fieldName);
		field.setAccessible(true);
		return field.get(clsObj);
	}

}
