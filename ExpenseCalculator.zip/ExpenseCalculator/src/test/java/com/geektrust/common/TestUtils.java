package com.geektrust.common;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import org.junit.jupiter.api.Test;

import com.geektrust.common.Utils;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static com.geektrust.constants.Constants.MEMBER_NOT_FOUND;
import static com.geektrust.constants.Constants.SUCCESS;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class TestUtils {
	Utils utils = new Utils();

	@Test
	public void doesNamesInFirstArrayPresentInSecondShouldReturnTrueIfPresent() {
		String[] names = new String[] { "user1", "user2" };
		Set<String> existingNames = new HashSet<>(Arrays.asList(names));
		boolean result = utils.doesNamesInFirstArrayPresentInSecond(names, existingNames);
		assertTrue(result);
	}

	@Test
	public void doesNamesInFirstArrayPresentInSecondShouldReturnFalseIfNotPresent() {
		String[] names = new String[] { "user1", "user2" };
		Set<String> existingNames = new HashSet<>(Arrays.asList(names));
		names[1] = "user3";
		boolean result = utils.doesNamesInFirstArrayPresentInSecond(names, existingNames);
		assertFalse(result);
	}

	@Test
	public void isSpendInputValidShouldReturnMemberNotFountIfInputMemberDoesntExist() {
		String[] inputs = new String[] { "SPEND", "1000", "user1", "user2" };
		Set<String> memberSet = new HashSet<>();
		memberSet.add("user1");
		memberSet.add("user3");
		String response = utils.isSpendInputValid(inputs, memberSet);
		assertEquals(MEMBER_NOT_FOUND, response);
	}

	@Test
	public void isSpendInputValidShouldReturnSuccessIfAllCorrest() {
		String[] inputs = new String[] { "SPEND", "1000", "user1", "user2" };
		Set<String> memberSet = new HashSet<>();
		memberSet.add("user1");
		memberSet.add("user2");
		String response = utils.isSpendInputValid(inputs, memberSet);
		assertEquals(SUCCESS, response);
	}


}
