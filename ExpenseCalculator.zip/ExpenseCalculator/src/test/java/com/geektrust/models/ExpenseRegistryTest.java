package com.geektrust.models;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class ExpenseRegistryTest {

	@Test
	public void addUsersToExpenseRegisterShouldAddAllNewUserEntries() {
		ExpenseRegistry expenseRegistry = new ExpenseRegistry();
		List<UserDues> newUserExpense = new ArrayList<UserDues>();
		newUserExpense.add(new UserDues("user1", "user2"));
		newUserExpense.add(new UserDues("user2", "user1"));
		expenseRegistry.addUsersToExpenseRegister(newUserExpense);
		assertEquals(2, expenseRegistry.getExpenseRegistry().size());
	}

	@Test
	public void getUserDuesFromRegistryShouldReturnOnlySpecificUser() {
		ExpenseRegistry expenseRegistry = new ExpenseRegistry();
		List<UserDues> newUserExpense = new ArrayList<UserDues>();
		newUserExpense.add(new UserDues("user1", "user2"));
		newUserExpense.add(new UserDues("user2", "user1"));
		List<UserDues> user1Due = expenseRegistry.getUserDuesFromRegistry("user1");
		List<UserDues> lstnonUser1Due = user1Due.stream()
				.filter(userDues -> !userDues.getBorower().equalsIgnoreCase("user1")).collect(Collectors.toList());
		if (lstnonUser1Due.size() > 0) {
			assertTrue(false);
		}
		assertTrue(true);
	}

	@Test
	public void getUserLendedDetailsFromRegistryShouldReturnOnlyLendedDetailsOfSpecificUser() {
		ExpenseRegistry expenseRegistry = new ExpenseRegistry();
		List<UserDues> newUserExpense = new ArrayList<UserDues>();
		newUserExpense.add(new UserDues("user1", "user2"));
		newUserExpense.add(new UserDues("user2", "user1"));
		List<UserDues> user1Due = expenseRegistry.getUserLendedDetailsFromRegistry("user1");
		List<UserDues> lstnonUser1Due = user1Due.stream()
				.filter(userDues -> !userDues.getLender().equalsIgnoreCase("user1")).collect(Collectors.toList());
		if (lstnonUser1Due.size() > 0) {
			assertTrue(false);
		}
		assertTrue(true);
	}

	@Test
	public void getUserLendedDetailsFromRegistryShouldReturnOnlyLendedDetailsForWhichLendedAmtGrtThanZero() {
		ExpenseRegistry expenseRegistry = new ExpenseRegistry();
		List<UserDues> newUserExpense = new ArrayList<UserDues>();
		newUserExpense.add(new UserDues("user1", "user2"));
		newUserExpense.add(new UserDues("user2", "user1"));
		List<UserDues> user1Due = expenseRegistry.getUserLendedDetailsFromRegistry("user1");
		List<UserDues> lstnonUser1Due = user1Due.stream().filter(userDues -> userDues.getDueAmount() <= 0)
				.collect(Collectors.toList());
		if (lstnonUser1Due.size() > 0) {
			assertTrue(false);
		}
		assertTrue(true);
	}

}
