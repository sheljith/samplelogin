package com.geektrust.models;

import org.junit.jupiter.api.Test;

import com.geektrust.models.Apartment;
import com.geektrust.services.ExpenseRegistryServices;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static com.geektrust.constants.Constants.MEMBER_COUNT_LIMIT;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class TestApartment {

	@Test
	public void getMemberCountShouldReturnCorrectMemberCount() {
		Apartment apartment = new Apartment();
		apartment.addMember("test");
		assertEquals(1, apartment.getMemberCount());
	}

	@Test
	public void getMemberCountShouldReturnZeroWhenNoMember() {
		Apartment apartment = new Apartment();
		assertEquals(0, apartment.getMemberCount());
	}

	@Test
	public void addMemberShouldAddNewMemberIfEmpty() {
		Apartment apartment = new Apartment();
		apartment.addMember("member1");
		assertEquals(1, apartment.getMemberCount());
	}

	@Test
	public void addMemberShouldAddNewMemberIfContainsLessMemberThanLimit() {
		Apartment apartment = new Apartment();
		for (int i = 0; i < MEMBER_COUNT_LIMIT; i++) {
			apartment.addMember("member" + i);
		}
		assertEquals(MEMBER_COUNT_LIMIT, apartment.getMemberCount());
	}

	@Test
	public void getMemberNamesShouldGiveCorrectNames() {
		Apartment apartment = new Apartment();
		Set<String> names = new HashSet<String>();
		for (int i = 0; i < MEMBER_COUNT_LIMIT; i++) {
			apartment.addMember("member" + i);
			names.add("member" + i);
		}
		assertTrue(names.equals(apartment.getMemberNames()));
	}

	@Test
	public void addNewUserToExpenseRegistryShouldAddExpenseRegistryCount() {
		Apartment apartment = new Apartment();
		ExpenseRegistryServices expenseRegService = new ExpenseRegistryServices();
		List<UserDues> newUserDues = expenseRegService.generateExpenseRegForNewUser("newUser",
				new HashSet<>(Arrays.asList(new String[] { "user1" })));
		apartment.addNewUserToExpenseRegistry(newUserDues);
		assertEquals(newUserDues.size(), apartment.getExpenseRegistry().getExpenseRegistry().size());
	}

	@Test
	public void addNewUserToExpenseRegistryShouldAddNewUserDuesToExisting() {
		Apartment apartment = new Apartment();
		ExpenseRegistryServices expenseRegService = new ExpenseRegistryServices();
		List<UserDues> newUserDues = expenseRegService.generateExpenseRegForNewUser("newUser",
				new HashSet<>(Arrays.asList(new String[] { "user1" })));
		apartment.addNewUserToExpenseRegistry(newUserDues);
		List<UserDues> aptmtUserDueList = apartment.getExpenseRegistry().getExpenseRegistry();
		long count = newUserDues.stream().filter(userDue -> !aptmtUserDueList.contains(userDue)).count();
		assertEquals(0, count);
	}

	@Test
	public void memberCountShouldReduceByOneAfterMoveout() {
		Apartment apartment = new Apartment();
		apartment.addMember("user1");
		apartment.addMember("user2");
		apartment.moveOut("user1");
		assertEquals(1, apartment.getMemberCount());

	}

	@Test
	public void memberShouldBeRemovedAfterMoveout() {
		Apartment apartment = new Apartment();
		apartment.addMember("user1");
		apartment.addMember("user2");
		apartment.moveOut("user1");
		assertFalse(apartment.getMemberNames().contains("user1"));
	}

	/*
	 * @Test public void addSpendDetailsShouldSplitEquallyInitially() { Apartment
	 * apartment = new Apartment(); apartment.addMember("ANDY");
	 * apartment.addMember("WOODY"); apartment.addMember("BO");
	 * apartment.addSpendDetails("SPEND 3000 ANDY WOODY BO".split(" "));
	 * List<String> dueListWoody = apartment.getOrderdDueList("WOODY"); List<String>
	 * dueListBo = apartment.getOrderdDueList("BO");
	 * assertTrue(dueListWoody.get(0).equals("ANDY 1000") &&
	 * dueListBo.get(0).equals("ANDY 1000")); }
	 * 
	 * @Test public void addSpendDetailsShouldSimplifyAndSplit() { Apartment
	 * apartment = new Apartment(); apartment.addMember("ANDY");
	 * apartment.addMember("WOODY"); apartment.addMember("BO");
	 * apartment.addSpendDetails("SPEND 3000 ANDY WOODY BO".split(" "));
	 * apartment.addSpendDetails("SPEND 300 WOODY BO".split(" ")); List<String>
	 * dueListWoody = apartment.getOrderdDueList("WOODY"); List<String> dueListBo =
	 * apartment.getOrderdDueList("BO");
	 * assertTrue(dueListWoody.get(0).equals("ANDY 850") &&
	 * dueListBo.get(0).equals("ANDY 1150")); }
	 * 
	 * @Test public void addSpendDetailsShouldReturnMemberNotFoundForUnknownUser() {
	 * Apartment apartment = new Apartment(); apartment.addMember("ANDY");
	 * apartment.addMember("WOODY"); String result =
	 * apartment.addSpendDetails("SPEND 3000 ANDY WOODY BO".split(" "));
	 * assertEquals(MEMBER_NOT_FOUND, result); }
	 */
}
