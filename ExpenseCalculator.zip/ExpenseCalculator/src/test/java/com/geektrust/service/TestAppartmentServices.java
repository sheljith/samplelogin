package com.geektrust.service;

import static com.geektrust.constants.Constants.MEMBER_NOT_FOUND;
import static com.geektrust.constants.Constants.SUCCESS;
import static com.geektrust.constants.Constants.FAILURE;
import static com.geektrust.constants.Constants.MEMBER_COUNT_LIMIT;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;

import com.geektrust.common.CommonUtilsForTest;
import com.geektrust.models.Apartment;
import com.geektrust.models.Member;
import com.geektrust.models.UserDues;
import com.geektrust.services.ApartmentService;

public class TestAppartmentServices {
	CommonUtilsForTest utils = new CommonUtilsForTest();
	ApartmentService apartmentService = new ApartmentService();

	@Test
	public void addMemberToAppartmentShouldAddMember() {
		Apartment apartment = new Apartment();
		apartmentService.addMemberToAppartment(apartment, "member1");
		assertEquals(1, apartment.getMemberCount());
	}

	@Test
	public void addMemberToAppartmentShouldNotAddMemberIfLimitReached() {
		Apartment apartment = new Apartment();
		for (int i = 0; i < MEMBER_COUNT_LIMIT; i++) {
			apartment.addMember("member" + i);
		}
		apartmentService.addMemberToAppartment(apartment, "member");
		assertEquals(MEMBER_COUNT_LIMIT, apartment.getMemberCount());
	}

	@Test
	public void addMemberToAppartmentShouldRestrictAddingExistingNames() {
		Apartment apartment = new Apartment();
		apartment.addMember("member");
		apartmentService.addMemberToAppartment(apartment, "member");
		assertEquals(1, apartment.getMemberCount());
	}

	@Test
	public void getOrderdDueListShouldProvideOrderdDueList() throws Exception {
		Apartment apartment = new Apartment();
		apartmentService.addMemberToAppartment(apartment, "ANDY");
		apartmentService.addMemberToAppartment(apartment, "WOODY");
		apartmentService.addMemberToAppartment(apartment, "BO");
		apartmentService.addSpendDetails(apartment, new String[] { "SPEND", "6000", "ANDY", "WOODY", "BO" });
		List<UserDues> userDues = apartmentService.getOrderdDueList(apartment, "WOODY");
		if (!userDues.get(0).getLender().equalsIgnoreCase("ANDY")
				&& !userDues.get(0).getLender().equalsIgnoreCase("BO")) {
			assertTrue(false);
		}
		assertTrue(true);
	}

	@Test
	public void getOrderdDueListShouldProvideOrderdDueListForSameAmount() throws Exception {
		Apartment apartment = new Apartment();
		apartmentService.addMemberToAppartment(apartment, "ANDY");
		apartmentService.addMemberToAppartment(apartment, "WOODY");
		apartmentService.addMemberToAppartment(apartment, "BO");
		apartmentService.addSpendDetails(apartment, new String[] { "SPEND", "6000", "ANDY", "WOODY" });
		apartmentService.addSpendDetails(apartment, new String[] { "SPEND", "6000", "BO", "WOODY" });
		List<UserDues> userDues = apartmentService.getOrderdDueList(apartment, "WOODY");
		if (!userDues.get(0).getLender().equalsIgnoreCase("ANDY")
				&& !userDues.get(0).getLender().equalsIgnoreCase("BO")) {
			assertTrue(false);
		}
		assertTrue(true);
	}

	@Test
	public void addSpendDetailsShouldReturnMemberNotFoundIfMemberIsNotPresnt() {
		Apartment apartment = new Apartment();
		assertEquals(MEMBER_NOT_FOUND,
				apartmentService.addSpendDetails(apartment, new String[] { "SPEND", "ABC", "1", "pasdas", "asda" }));
	}

	@Test
	public void addSpendDetailsShouldReturnSuccessIfAllGood() {
		Apartment apartment = new Apartment();
		apartmentService.addMemberToAppartment(apartment, "ANDY");
		apartmentService.addMemberToAppartment(apartment, "WOODY");
		apartmentService.addMemberToAppartment(apartment, "BO");
		assertEquals(SUCCESS,
				apartmentService.addSpendDetails(apartment, new String[] { "SPEND", "6000", "ANDY", "WOODY" }));
	}

	@Test
	public void clearDuesShouldReturnNegTwoIfMemberNotFount() {
		Apartment apartment = new Apartment();
		apartmentService.addMemberToAppartment(apartment, "ANDY");
		apartmentService.addMemberToAppartment(apartment, "WOODY");
		apartmentService.addMemberToAppartment(apartment, "BO");
		assertEquals(-2, apartmentService.clearDues(apartment, "asd", "asdasd", 10));
	}

	@Test
	public void moveOutShouldReturnMemberNotFoundIfWrongMemberName() {
		Apartment apartment = new Apartment();
		apartmentService.addMemberToAppartment(apartment, "ANDY");
		apartmentService.addMemberToAppartment(apartment, "WOODY");
		apartmentService.addMemberToAppartment(apartment, "BO");
		assertEquals(MEMBER_NOT_FOUND, apartmentService.moveOut(apartment, "JOHN"));
	}

	@Test
	public void moveOutShouldReturnFailureIfMemberNotElgibleForMoveOut() {
		Apartment apartment = new Apartment();
		apartmentService.addMemberToAppartment(apartment, "ANDY");
		apartmentService.addMemberToAppartment(apartment, "WOODY");
		apartmentService.addMemberToAppartment(apartment, "BO");
		apartmentService.addSpendDetails(apartment, new String[] { "SPEND", "6000", "ANDY", "WOODY" });
		assertEquals(FAILURE, apartmentService.moveOut(apartment, "WOODY"));
	}

	@Test
	public void moveOutShouldReturnSuccessIfMemberElgibleForMoveOut() {
		Apartment apartment = new Apartment();
		apartmentService.addMemberToAppartment(apartment, "ANDY");
		apartmentService.addMemberToAppartment(apartment, "WOODY");
		apartmentService.addMemberToAppartment(apartment, "BO");
		assertEquals(SUCCESS, apartmentService.moveOut(apartment, "WOODY"));
	}

	/*
	 * @Test public void moveOutShouldReturnMemberNotFoundIfNotpresent() {
	 * Map<String, Member> members = new HashMap<String, Member>();
	 * assertEquals(MEMBER_NOT_FOUND, apartmentService.moveOut("member2", members));
	 * }
	 */

}
