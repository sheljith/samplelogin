package com.geektrust.service;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.junit.jupiter.api.Test;

import com.geektrust.models.ExpenseRegistry;
import com.geektrust.models.UserDues;
import com.geektrust.services.ExpenseRegistryServices;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertFalse;

public class ExpenseRegistryServicesTest {

	ExpenseRegistryServices expenseServices = new ExpenseRegistryServices();
	ExpenseRegistry reg = new ExpenseRegistry();

	@Test
	public void generateExpenseRegForNewUserShouldNotReturnNullIfExistingUserIsEmpty() {
		List<UserDues> newUserExpense = expenseServices.generateExpenseRegForNewUser("newUser", new HashSet<String>());
		assertTrue(null != newUserExpense);
	}

	@Test
	public void generateExpenseRegForNewUserShouldReturnEmptyMapIfExistingUserIsEmpty() {
		List<UserDues> newUserExpense = expenseServices.generateExpenseRegForNewUser("newUser", new HashSet<String>());
		assertEquals(0, newUserExpense.size());
	}

	@Test
	public void generateExpenseRegForNewUserShouldReturnProperDeltaRegistry() {
		List<UserDues> newUserExpense = expenseServices.generateExpenseRegForNewUser("newUser",
				new HashSet<>(Arrays.asList("User1", "User2")));
		Set<String> lenderBorrowerSet = newUserExpense.stream()
				.map(userDue -> userDue.getBorower() + "-" + userDue.getLender()).collect(Collectors.toSet());
		if (!lenderBorrowerSet.contains("newUser-User1") || !lenderBorrowerSet.contains("newUser-User2")
				|| !lenderBorrowerSet.contains("User1-newUser") || !lenderBorrowerSet.contains("User2-newUser")) {
			assertTrue(false);
		} else {
			assertTrue(true);
		}
	}

	@Test
	public void generateExpenseRegForNewUserShouldReturnProperDeltaRegistryWithZeroDues() {
		List<UserDues> newUserExpense = expenseServices.generateExpenseRegForNewUser("newUser",
				new HashSet<>(Arrays.asList("User1", "User2")));
		Set<Integer> values = newUserExpense.stream().map(userDue -> userDue.getDueAmount())
				.collect(Collectors.toSet());
		if (!values.contains(0) || values.size() != 1) {
			assertTrue(false);
		} else {
			assertTrue(true);
		}
	}

	@Test
	public void simplifyAndAddExpenceShouldAddProperlyForFirstExpense() {
		loadUserDuesToReg();
		expenseServices.simplifyAndAddExpence(reg, "ANDY", Arrays.asList(new String[] { "WOODY", "BO" }), 2000);

		assertTrue(expenseServices.getUserDueOfASpecificLenderAndBorrower(reg, "ANDY", "WOODY").getDueAmount() == 2000
				&& expenseServices.getUserDueOfASpecificLenderAndBorrower(reg, "ANDY", "BO").getDueAmount() == 2000);

	}

	@Test
	public void simplifyAndAddExpenceShouldSimplifyDues() {
		loadUserDuesToReg();
		expenseServices.simplifyAndAddExpence(reg, "ANDY", Arrays.asList(new String[] { "WOODY", "BO" }), 2000);

		expenseServices.simplifyAndAddExpence(reg, "WOODY", Arrays.asList(new String[] { "ANDY" }), 1500);
		assertTrue(expenseServices.getUserDueOfASpecificLenderAndBorrower(reg, "ANDY", "WOODY").getDueAmount() == 500
				&& expenseServices.getUserDueOfASpecificLenderAndBorrower(reg, "ANDY", "BO").getDueAmount() == 2000);

	}

	@Test
	public void simplifyAndAddExpenceShouldSimplifyDuesTestCase2() {
		loadUserDuesToReg();
		expenseServices.simplifyAndAddExpence(reg, "ANDY", Arrays.asList(new String[] { "WOODY", "BO" }), 2000);

		expenseServices.simplifyAndAddExpence(reg, "WOODY", Arrays.asList(new String[] { "ANDY" }), 1500);
		expenseServices.simplifyAndAddExpence(reg, "BO", Arrays.asList(new String[] { "ANDY", "WOODY" }), 4000);
		assertTrue(expenseServices.getUserDueOfASpecificLenderAndBorrower(reg, "ANDY", "WOODY").getDueAmount() == 0
				&& expenseServices.getUserDueOfASpecificLenderAndBorrower(reg, "ANDY", "BO").getDueAmount() == 0
				&& expenseServices.getUserDueOfASpecificLenderAndBorrower(reg, "BO", "ANDY").getDueAmount() == 1500
				&& expenseServices.getUserDueOfASpecificLenderAndBorrower(reg, "BO", "WOODY").getDueAmount() == 4500);

	}

	public void loadUserDuesToReg() {
		reg = new ExpenseRegistry();
		HashSet<String> users = new HashSet<String>();
		reg.addUsersToExpenseRegister(expenseServices.generateExpenseRegForNewUser("ANDY", users));
		users.add("ANDY");
		reg.addUsersToExpenseRegister(expenseServices.generateExpenseRegForNewUser("WOODY", users));
		users.add("WOODY");
		reg.addUsersToExpenseRegister(expenseServices.generateExpenseRegForNewUser("BO", users));
	}

	@Test
	public void getUserDueOfASpecificLenderAndBorrowerShouldReturnMentionedLenderAndBorOwerDue() {
		loadUserDuesToReg();
		expenseServices.simplifyAndAddExpence(reg, "ANDY", Arrays.asList(new String[] { "WOODY", "BO" }), 2000);
		UserDues userDue = expenseServices.getUserDueOfASpecificLenderAndBorrower(reg, "ANDY", "WOODY");
		assertTrue(userDue.getBorower().equalsIgnoreCase("WOODY") && userDue.getLender().equalsIgnoreCase("ANDY"));
	}

	@Test
	public void clearDuesShouldNReturnNegOneIfDueAmountIsLessThanTheAmount() {
		loadUserDuesToReg();
		expenseServices.simplifyAndAddExpence(reg, "ANDY", Arrays.asList(new String[] { "WOODY", "BO" }), 2000);
		int result = expenseServices.clearDues(reg, "ANDY", "WOODY", 10000);
		assertEquals(-1, result);
	}

	@Test
	public void clearDuesShouldNotClearDueIfDueAmountIsLessThanTheAmount() {
		loadUserDuesToReg();
		expenseServices.simplifyAndAddExpence(reg, "ANDY", Arrays.asList(new String[] { "WOODY", "BO" }), 2000);
		UserDues userDue = expenseServices.getUserDueOfASpecificLenderAndBorrower(reg, "ANDY", "WOODY");
		int dueBeforeClearCommand = userDue.getDueAmount();
		expenseServices.clearDues(reg, "ANDY", "WOODY", 10000);
		int dueAfterClearCommand = userDue.getDueAmount();
		assertEquals(dueAfterClearCommand, dueBeforeClearCommand);
	}

	@Test
	public void clearDuesShouldReduceTheDueAmount() {
		loadUserDuesToReg();
		UserDues userDue = expenseServices.getUserDueOfASpecificLenderAndBorrower(reg, "ANDY", "WOODY");
		expenseServices.simplifyAndAddExpence(reg, "ANDY", Arrays.asList(new String[] { "WOODY", "BO" }), 2000);
		int dueBeforeClearCommand = userDue.getDueAmount();
		expenseServices.clearDues(reg, "ANDY", "WOODY", 1000);
		int dueAfterClearCommand = userDue.getDueAmount();
		assertEquals(dueBeforeClearCommand - 1000, dueAfterClearCommand);
	}

	@Test
	public void clearDuesShouldReturnTheBalanceDueAmount() {
		loadUserDuesToReg();
		UserDues userDue = expenseServices.getUserDueOfASpecificLenderAndBorrower(reg, "ANDY", "WOODY");
		// int dueBeforeClearCommand = userDue.getDueAmount();
		expenseServices.simplifyAndAddExpence(reg, "ANDY", Arrays.asList(new String[] { "WOODY", "BO" }), 2000);
		int result = expenseServices.clearDues(reg, "ANDY", "WOODY", 1000);
		int dueAfterClearCommand = userDue.getDueAmount();
		assertEquals(dueAfterClearCommand, result);
	}

	@Test
	public void isMemberReadyToMoveOutShouldRetrunFalseIfMemberHasDues() {
		loadUserDuesToReg();
		expenseServices.simplifyAndAddExpence(reg, "ANDY", Arrays.asList(new String[] { "WOODY", "BO" }), 2000);
		assertFalse(expenseServices.isMemberReadyToMoveOut(reg, "WOODY"));
	}

	@Test
	public void isMemberReadyToMoveOutShouldRetrunFalseIfMemberAnyOtherHasDueToHim() {
		loadUserDuesToReg();
		expenseServices.simplifyAndAddExpence(reg, "ANDY", Arrays.asList(new String[] { "WOODY", "BO" }), 2000);
		assertFalse(expenseServices.isMemberReadyToMoveOut(reg, "ANDY"));
	}

	@Test
	public void isMemberReadyToMoveOutShouldRetrunTrueIfNoDuesOrNobodyHasDueToHim() {
		loadUserDuesToReg();
		assertTrue(expenseServices.isMemberReadyToMoveOut(reg, "ANDY"));
	}

	@Test
	public void removeMemberDetailsFromRegistryShouldRemoveAllEntriesOfUserAsBorowerAndLender() {
		loadUserDuesToReg();
		expenseServices.removeMemberDetailsFromRegistry(reg, "ANDY");
		long dueCountWithRemovedUser = reg.getExpenseRegistry().stream()
				.filter(due -> due.getBorower().equalsIgnoreCase("ANDY") || due.getLender().equalsIgnoreCase("ANDY"))
				.count();
		assertEquals(0, dueCountWithRemovedUser);
	}

}
