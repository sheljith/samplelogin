package com.geektrust.application;

import static com.geektrust.constants.Constants.INCORRECT_PAYMENT;
import static com.geektrust.constants.Constants.INPUT_CLEAR_DUE;
import static com.geektrust.constants.Constants.INPUT_DUES;
import static com.geektrust.constants.Constants.INPUT_MOVE_IN;
import static com.geektrust.constants.Constants.INPUT_MOVE_OUT;
import static com.geektrust.constants.Constants.INPUT_SPEND;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;

import com.geektrust.models.Apartment;
import com.geektrust.models.UserDues;
import com.geektrust.services.ApartmentService;

/**
 * ExpenseCalculator is a tool that helps housemates calculate and manage their
 * expenses
 * 
 * @author skrishnan
 *
 */
public class ExpenseCalculator {
	private Apartment apartment;
	private ApartmentService apartmentService;

	public static void main(String[] args) throws FileNotFoundException, IOException {
		ExpenseCalculator expenseCalculator = new ExpenseCalculator();
		expenseCalculator.apartmentService = new ApartmentService();
		expenseCalculator.apartment = new Apartment();
		String filePath = args[0];
		try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
			String line = br.readLine();
			while (null != line) {
				expenseCalculator.processInputLine(line);
				line = br.readLine();
			}
		}
	}

	private void processInputLine(String line) {
		String inputs[] = line.split(" ");
		switch (inputs[0]) {
		case INPUT_MOVE_IN:
			apartmentService.addMemberToAppartment(apartment, inputs[1]);
			break;
		case INPUT_SPEND:
			System.out.println(apartmentService.addSpendDetails(apartment, inputs));
			break;
		case INPUT_DUES:
			List<UserDues> userDues = apartmentService.getOrderdDueList(apartment, inputs[1]);
			userDues.forEach(userDue -> System.out.println(userDue.getLender() + " " + userDue.getDueAmount()));
			break;
		case INPUT_CLEAR_DUE:
			int balance = apartmentService.clearDues(apartment, inputs[1], inputs[2], Integer.parseInt(inputs[3]));
			if (balance == -1) {
				System.out.println(INCORRECT_PAYMENT);
				// -2 is when members not found
			} else if (balance != -2) {
				System.out.println(balance);
			}
			break;
		case INPUT_MOVE_OUT:
			System.out.println(apartmentService.moveOut(apartment, inputs[1]));
			break;

		}
	}

}
