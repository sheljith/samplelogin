package com.geektrust.models;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class Apartment {

	private List<Member> members;
	private ExpenseRegistry expenseRegister;

	public Apartment() {
		this.members = new ArrayList<Member>();
		this.expenseRegister = new ExpenseRegistry();
	}

	public int getMemberCount() {
		return members.size();
	}

	public void addMember(String memberName) {
		Member newMember = new Member(memberName);
		members.add(newMember);
	}

	public Set<String> getMemberNames() {
		return members.stream().map(member -> member.getName()).collect(Collectors.toSet());
	}

	public void addNewUserToExpenseRegistry(List<UserDues> newUserExpenseReg) {
		expenseRegister.addUsersToExpenseRegister(newUserExpenseReg);
	}

	public ExpenseRegistry getExpenseRegistry() {
		return expenseRegister;
	}

	public List<UserDues> getUserDues(String user) {
		return expenseRegister.getUserDuesFromRegistry(user);
	}

	public void moveOut(String memberName) {
		List<Member> membersToBeRemoved = members.stream()
				.filter(member -> member.getName().equalsIgnoreCase(memberName)).collect(Collectors.toList());
		this.members.removeAll(membersToBeRemoved);
	}
}
