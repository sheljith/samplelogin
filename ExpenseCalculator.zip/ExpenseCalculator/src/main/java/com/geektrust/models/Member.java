package com.geektrust.models;

public class Member {

	private String name;

	public String getName() {
		return name;
	}

	public Member(String name) {
		this.name = name;
	}

}
