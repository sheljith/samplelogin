package com.geektrust.models;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class ExpenseRegistry {

	private List<UserDues> expenseRegistry;

	public ExpenseRegistry() {
		expenseRegistry = new ArrayList<UserDues>();
	}

	public void addUsersToExpenseRegister(List<UserDues> newUserExpense) {
		expenseRegistry.addAll(newUserExpense);
	}

	public List<UserDues> getExpenseRegistry() {
		return expenseRegistry;
	}

	public List<UserDues> getUserDuesFromRegistry(String user) {
		return expenseRegistry.stream().filter(userDue -> userDue.getBorower().equalsIgnoreCase(user))
				.collect(Collectors.toList());
	}

	/**
	 * will fetch all due list where user passed as parameter will be the lender and
	 * lended amount is greater than 0
	 * 
	 * @param user
	 * @return
	 */
	public List<UserDues> getUserLendedDetailsFromRegistry(String user) {
		return expenseRegistry.stream()
				.filter(userDue -> userDue.getLender().equalsIgnoreCase(user) && userDue.getDueAmount() > 0)
				.collect(Collectors.toList());
	}

}
