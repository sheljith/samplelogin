package com.geektrust.models;

public class UserDues implements Comparable<UserDues> {
	private String lender;
	private String borower;
	private Integer dueAmount;

	public UserDues(String lender, String borower) {
		this.lender = lender;
		this.borower = borower;
		this.dueAmount = 0;
	}

	public Integer getDueAmount() {
		return dueAmount;
	}

	public void setDueAmount(Integer dueAmount) {
		this.dueAmount = dueAmount;
	}

	public String getLender() {
		return lender;
	}

	public String getBorower() {
		return borower;
	}

	public void addDue(int due) {
		this.dueAmount += due;
	}

	public int reduceDue(int due) {
		this.dueAmount -= due;
		return this.dueAmount;
	}

	@Override
	public int compareTo(UserDues userDue) {
		int difference = ((UserDues) userDue).getDueAmount().compareTo(this.dueAmount);
		if (difference == 0) {
			difference = this.lender.compareTo(((UserDues) userDue).getLender());
		}
		return difference;
	}
}
