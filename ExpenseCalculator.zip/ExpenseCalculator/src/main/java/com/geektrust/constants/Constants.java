package com.geektrust.constants;

public class Constants {

	public static final String INPUT_MOVE_IN = "MOVE_IN";
	public static final String INPUT_SPEND = "SPEND";
	public static final String INPUT_DUES = "DUES";
	public static final String INPUT_CLEAR_DUE = "CLEAR_DUE";
	public static final String INPUT_MOVE_OUT = "MOVE_OUT";

	public static final int MEMBER_COUNT_LIMIT = 3;
	public static final String SUCCESS = "SUCCESS";
	public static final String HOUSEFUL = "HOUSEFUL";
	public static final String MEMBER_NOT_FOUND = "MEMBER_NOT_FOUND";
	public static final String FAILURE = "FAILURE";
	public static final String INCORRECT_PAYMENT = "INCORRECT_PAYMENT";

}
