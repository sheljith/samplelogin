package com.geektrust.services;

import static com.geektrust.constants.Constants.FAILURE;
import static com.geektrust.constants.Constants.HOUSEFUL;
import static com.geektrust.constants.Constants.MEMBER_COUNT_LIMIT;
import static com.geektrust.constants.Constants.MEMBER_NOT_FOUND;
import static com.geektrust.constants.Constants.SUCCESS;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import com.geektrust.common.Utils;
import com.geektrust.models.Apartment;
import com.geektrust.models.UserDues;

public class ApartmentService {

	private Utils utils = new Utils();
	private ExpenseRegistryServices expenseRegService = new ExpenseRegistryServices();

	/**
	 * adds new member to apartment if not full or the username doesnt already
	 * exists
	 * 
	 * @param apartment
	 * @param newMemberName
	 */
	public void addMemberToAppartment(Apartment apartment, String newMemberName) {
		if (apartment.getMemberCount() == MEMBER_COUNT_LIMIT) {
			System.out.println(HOUSEFUL);
		} else {
			if (apartment.getMemberNames().contains(newMemberName)) {
				System.out.println(FAILURE);
			} else {
				List<UserDues> newExpenseEntries = expenseRegService.generateExpenseRegForNewUser(newMemberName,
						apartment.getMemberNames());
				apartment.addMember(newMemberName);
				apartment.addNewUserToExpenseRegistry(newExpenseEntries);
				System.out.println(SUCCESS);
			}
		}
	}

	public String addSpendDetails(Apartment apartment, String[] inputs) {
		String validationResult = utils.isSpendInputValid(inputs, apartment.getMemberNames());
		if (!validationResult.equals(SUCCESS)) {
			return validationResult;
		}
		int spendAmount = Integer.parseInt(inputs[1]);
		// first 2 input values are 'spend' command and amount.
		int noOfMembers = inputs.length - 2;
		int share = Math.round(spendAmount / noOfMembers);
		String[] borowers = Arrays.copyOfRange(inputs, 3, inputs.length);
		String lender = inputs[2];
		expenseRegService.simplifyAndAddExpence(apartment.getExpenseRegistry(), lender, Arrays.asList(borowers), share);
		return SUCCESS;
	}

	public List<UserDues> getOrderdDueList(Apartment apartment, String user) {
		if (!utils.doesNamesInFirstArrayPresentInSecond(new String[] { user }, apartment.getMemberNames())) {
			System.out.println(MEMBER_NOT_FOUND);
			return new ArrayList<UserDues>();
		}
		List<UserDues> userDues = apartment.getUserDues(user);
		Collections.sort(userDues);
		return userDues;
	}

	/**
	 * clears due if the amount is same or less than the due amount
	 * 
	 * @param apartment
	 * @param borowerName
	 * @param lenderName
	 * @param amount
	 * @return -2 if member not found -1 if amount greater than due balance due if
	 *         amount is less than or equal to due
	 */
	public int clearDues(Apartment apartment, String borowerName, String lenderName, int amount) {
		if (!utils.doesNamesInFirstArrayPresentInSecond(new String[] { borowerName, lenderName },
				apartment.getMemberNames())) {
			System.out.println(MEMBER_NOT_FOUND);
			return -2;
		}
		int remainingDue = expenseRegService.clearDues(apartment.getExpenseRegistry(), lenderName, borowerName, amount);
		return remainingDue;
	}

	public String moveOut(Apartment apartment, String memberName) {
		if (!utils.doesNamesInFirstArrayPresentInSecond(new String[] { memberName }, apartment.getMemberNames())) {
			return MEMBER_NOT_FOUND;
		}
		if (expenseRegService.isMemberReadyToMoveOut(apartment.getExpenseRegistry(), memberName)) {
			apartment.moveOut(memberName);
			expenseRegService.removeMemberDetailsFromRegistry(apartment.getExpenseRegistry(), memberName);
			return SUCCESS;
		}
		return FAILURE;
	}
}
