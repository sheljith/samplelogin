package com.geektrust.services;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import com.geektrust.models.ExpenseRegistry;
import com.geektrust.models.UserDues;

public class ExpenseRegistryServices {

	public List<UserDues> generateExpenseRegForNewUser(String newUser, Set<String> existingUsers) {
		List<UserDues> newUserExpenseReg = new ArrayList<UserDues>();
		existingUsers.forEach(user -> {
			newUserExpenseReg.add(new UserDues(newUser, user));
			newUserExpenseReg.add(new UserDues(user, newUser));
		});
		return newUserExpenseReg;
	}

	public void simplifyAndAddExpence(ExpenseRegistry expenseRegister, String lender, List<String> borowers,
			int share) {
		borowers.forEach(borower -> {
			UserDues lenderBorowerDue = getUserDueOfASpecificLenderAndBorrower(expenseRegister, borower, lender);
			int lenderDueToBorower = lenderBorowerDue.getDueAmount();
			int borowerShare = share;
			if (lenderDueToBorower > borowerShare) {
				lenderBorowerDue.reduceDue(borowerShare);
				return;
			} else if (lenderDueToBorower > 0 && lenderDueToBorower < share) {
				lenderBorowerDue.reduceDue(lenderDueToBorower);
				borowerShare = borowerShare - lenderDueToBorower;
			}
			borowerShare = simplifyBorowerDue(expenseRegister, lender, borower, borowerShare);
			if (borowerShare == 0) {
				return;
			}
			borowerShare = simplifylendersDues(expenseRegister, lender, borower, borowerShare);
			UserDues currentBorowerDueToLender = getUserDueOfASpecificLenderAndBorrower(expenseRegister, lender,
					borower);
			currentBorowerDueToLender.addDue(borowerShare);
		});
	}

	public int simplifyBorowerDue(ExpenseRegistry expenseRegister, String lender, String borower, int borowerShare) {
		List<UserDues> duesOfUsersWhoOwesBorrower = expenseRegister.getUserLendedDetailsFromRegistry(borower);
		for (UserDues userDueForBorower : duesOfUsersWhoOwesBorrower) {
			String userName = userDueForBorower.getBorower();
			int userDueAmountForBorower = userDueForBorower.getDueAmount();
			UserDues userDueToLender = getUserDueOfASpecificLenderAndBorrower(expenseRegister, lender, userName);
			if (userDueAmountForBorower > borowerShare) {
				userDueForBorower.reduceDue(borowerShare);
				userDueToLender.addDue(borowerShare);
				return 0;
			} else if (userDueAmountForBorower > 0 && userDueAmountForBorower < borowerShare) {
				userDueForBorower.reduceDue(userDueAmountForBorower);
				userDueToLender.addDue(userDueAmountForBorower);
				borowerShare = borowerShare - userDueAmountForBorower;
			}
		}
		return borowerShare;
	}

	public int simplifylendersDues(ExpenseRegistry expenseRegister, String lender, String borower, int borowerShare) {
		List<UserDues> duesOflenderToOtherUsers = expenseRegister.getUserDuesFromRegistry(lender);
		for (UserDues duesOfBorower : duesOflenderToOtherUsers) {
			String userName = duesOfBorower.getLender();
			if (userName.equalsIgnoreCase(borower)) {
				continue;
			}
			int dueAmountOfBorower = duesOfBorower.getDueAmount();
			UserDues userDueToBorower = getUserDueOfASpecificLenderAndBorrower(expenseRegister, userName, borower);
			if (dueAmountOfBorower > borowerShare) {
				duesOfBorower.reduceDue(borowerShare);
				userDueToBorower.addDue(borowerShare);
				return 0;
			} else if (dueAmountOfBorower > 0 && dueAmountOfBorower < borowerShare) {
				duesOfBorower.reduceDue(dueAmountOfBorower);
				userDueToBorower.addDue(dueAmountOfBorower);
				borowerShare = borowerShare - dueAmountOfBorower;
			}
		}
		return borowerShare;
	}

	public UserDues getUserDueOfASpecificLenderAndBorrower(ExpenseRegistry expenseRegister, String lender,
			String borower) {
		List<UserDues> lenderBorrorDue = expenseRegister.getExpenseRegistry().stream()
				.filter(userDue -> userDue.getBorower().equalsIgnoreCase(borower)
						&& userDue.getLender().equalsIgnoreCase(lender))
				.collect(Collectors.toList());
		// only one entry will be present with lender and borrower name
		return lenderBorrorDue.get(0);
	}

	public int clearDues(ExpenseRegistry expenseRegistry, String lenderName, String borowerName, int amount) {
		UserDues userDue = getUserDueOfASpecificLenderAndBorrower(expenseRegistry, lenderName, borowerName);
		if (userDue.getDueAmount() < amount) {
			return -1;
		}
		return userDue.reduceDue(amount);
	}

	public boolean isMemberReadyToMoveOut(ExpenseRegistry expenseRegistry, String memberName) {
		List<UserDues> userDues = expenseRegistry.getUserDuesFromRegistry(memberName);
		userDues = userDues.stream().filter(user -> user.getDueAmount() > 0).collect(Collectors.toList());
		if (userDues.size() > 0) {
			return false;
		}
		userDues = expenseRegistry.getUserLendedDetailsFromRegistry(memberName);
		if (userDues.size() > 0) {
			return false;
		}
		return true;
	}

	public void removeMemberDetailsFromRegistry(ExpenseRegistry expenseRegistry, String memberName) {
		List<UserDues> expenseRegister = expenseRegistry.getExpenseRegistry();
		List<UserDues> userDuesToBeRemoved = expenseRegister.stream().filter(
				user -> user.getBorower().equalsIgnoreCase(memberName) || user.getLender().equalsIgnoreCase(memberName))
				.collect(Collectors.toList());
		expenseRegister.removeAll(userDuesToBeRemoved);
	}

}
