package com.geektrust.common;

import static com.geektrust.constants.Constants.FAILURE;
import static com.geektrust.constants.Constants.MEMBER_NOT_FOUND;
import static com.geektrust.constants.Constants.SUCCESS;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import com.geektrust.models.Member;

public class Utils {

	public boolean doesNamesInFirstArrayPresentInSecond(String[] names, Set<String> existingNames) {
		for (String name : names) {
			if (!existingNames.contains(name)) {
				return false;
			}
		}
		return true;
	}

	/**
	 * validates the spend input command
	 * 
	 * @param inputs
	 * @param members
	 * @return
	 */
	public String isSpendInputValid(String[] inputs, Set<String> members) {
		String[] expensePartners = Arrays.copyOfRange(inputs, 2, inputs.length);
		if (!doesNamesInFirstArrayPresentInSecond(expensePartners, members)) {
			return MEMBER_NOT_FOUND;
		}
		if (members.size() < 2) {
			return FAILURE;
		}
		return SUCCESS;
	}

}
